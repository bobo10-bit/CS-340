from pymongo import MongoClient
from bson.objectid import ObjectId
from pymongo.errors import PyMongoError
import pandas as pd


class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, username, password):
        # Connection Variables
        
        USER = 'aacuser'
        PASS = 'password'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32775
        DB = 'AAC'
        COL = 'animals'
        
        uri = f"mongodb://{username}:{password}@{HOST}:{PORT}/{DB}?authSource={DB}"
        self.client = MongoClient(uri)

        # Initialize Connection
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """
        Inserts a document into the animals collection.
        :param data: A dictionary representing the document to be inserted.
        :return: True if the insert is successful, else False.
        """
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except PyMongoError as e:
                print(f"An error occurred while inserting the document: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """
        Finds documents in the animals collection based on a query.
        :param query: A dictionary representing the query to find the documents.
        :return: A list of documents if the query is successful, else an empty list.
        """
        if query is not None:
            try:
                cursor = self.collection.find(query)  
                documents = list(cursor) if cursor else []
                print(f"Query returned {len(documents)} documents.")
                return documents
            except PyMongoError as e:
                print(f"An error occurred while finding documents: {e}")
                return []
        else:
            raise Exception("Query parameter is empty")

    def update(self, query, update_values):
        if query is not None:
            try:
                result = self.collection.update_many(query, update_values)
                return result.modified_count
            except PyMongoError as e:
                print(f"An error occurred while updating documents: {e}")
                return 0

    def delete(self, query):
        if query is not None:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except PyMongoError as e:
                print(f"An error occurred while deleting documents: {e}")
                return 0
    